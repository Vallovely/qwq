miss(20);//�����˺�

function miss(percent)
{
	var num = Math.floor((Math.random() * 100) + 1);
	if (num < percent)
	{
		event.setDamage(0);
		event.getSource().sendMessage(npc.getName()+": miss��")
	}
	return;
}