strong();//�����˺�

function strong()
{
	var entity = npc.getSurroundingEntities(7, 1);
	var count = entity.length;
	event.setDamage(event.getDamage() * (count - 1) / count);
	return;
}