ascend();//����Attack

function ascend()
{
	var player = event.getTarget();
	player.setPosition(player.x, player.y + 5, player.z);
	return;
}