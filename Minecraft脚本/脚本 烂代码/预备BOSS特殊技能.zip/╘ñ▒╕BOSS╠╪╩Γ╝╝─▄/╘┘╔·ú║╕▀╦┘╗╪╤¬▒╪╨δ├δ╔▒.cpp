regeneration(5);//�����˺�

function regeneration(seconds)
{
	npc.addPotionEffect(6, seconds * 20, 8, true)
	return;
}