hatred();//����Attack

function hatred()
{
	var pct = npc.getHealth() / npc.getMaxHealth();
	event.setDamage(event.getDamage() * (2 - pct));
	return;
}