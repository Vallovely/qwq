commensal();//����Attack

function commensal()
{
	var player = event.getTarget();
	var hp = (npc.getHealth() + player.getHealth()) / 2;
	player.setHealth((hp < player.getMaxHealth()) ? hp : player.getMaxHealth());
	npc.setHealth((hp < npc.getMaxHealth()) ? hp : npc.getMaxHealth());
	return;
}