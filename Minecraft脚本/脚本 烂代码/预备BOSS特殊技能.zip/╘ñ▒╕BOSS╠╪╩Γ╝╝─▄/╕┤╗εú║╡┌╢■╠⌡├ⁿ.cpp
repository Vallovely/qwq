revive();//����killed

function revive()
{
	var ScriptPlayer = Java.type("noppes.npcs.scripted.ScriptPlayer");
	npc.setTempData("life", (npc.getTempData("life") == null ? 1 : npc.getTempData("life")));
	var x = npc.getTempData("life");
	if (x == 1)
	{
		npc.setTempData("life", 2);
		event.setCancelled(true);
		npc.setHealth(npc.getMaxHealth());
		var entity = event.getSource();
		entity.sendMessage(npc.getName() + ": ӭ�����������");
	}
	else
	{
		npc.setTempData("life", 1);
		var entity = event.getSource();
		entity.sendMessage(npc.getName() + ": ���ս�������");
	}
	return;
}