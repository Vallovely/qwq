armor("magic");//�����˺�

function armor(immumeWhat)
{
	var judge1 = (immumeWhat == "magic");
	var judge2 = event.getSource().getHeldItem().isEnchanted();
	if (judge1 == judge2)
	{
		event.setDamage(event.getDamage() / 10);
	}
	return;
}